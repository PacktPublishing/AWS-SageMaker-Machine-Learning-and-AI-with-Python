Bike Sharing Demand
https://www.kaggle.com/c/bike-sharing-demand/data

Download train.csv and test.csv from kaggle.

You would need to sign-in to Kaggle.com for downloading competition data.

Github Location: https://github.com/awslabs/machine-learning-samples/tree/master/social-media

Training Set and Schema File:
https://aml-sample-data.s3.amazonaws.com/social-media/aml_training_dataset.csv
https://aml-sample-data.s3.amazonaws.com/social-media/aml_training_dataset.csv.schema

S3 Location:
For training model, directly point to below S3 Location.  Schema will be automatically detected from the schema
definition file.

s3://aml-sample-data/social-media/aml_training_dataset.csv
s3://aml-sample-data/social-media/aml_training_dataset.csv.schema
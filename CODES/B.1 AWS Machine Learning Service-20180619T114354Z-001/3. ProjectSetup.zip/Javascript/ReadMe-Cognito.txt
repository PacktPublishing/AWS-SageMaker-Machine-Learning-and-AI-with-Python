AWS Cognito integration

Cognito is Amazon's identity management and data management service for mobile devices.

We will use Cognito to demonstrate integration scenario where only registered users of your application
can access prediction services.

Note: I have included necessary javascript libraries for you in the solution.

The below location is contains the resources where library is maintained.

Cognito Source code:
https://github.com/aws/amazon-cognito-identity-js/
http://docs.aws.amazon.com/cognito/latest/developerguide/tutorial-integrating-user-pools-javascript.html